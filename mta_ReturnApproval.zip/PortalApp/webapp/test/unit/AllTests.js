sap.ui.define([
	"ui/incture/PortalApp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});