sap.ui.define([
	"com/incture/vendorReturns/test/unit/controller/View1.controller"
], function () {
	"use strict";
});