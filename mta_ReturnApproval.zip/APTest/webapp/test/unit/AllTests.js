sap.ui.define([
	"ui/incture/APInvoiceTask/test/unit/controller/View1.controller"
], function () {
	"use strict";
});